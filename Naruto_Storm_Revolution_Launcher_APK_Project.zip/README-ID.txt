NARUTO STORM REVOLUTION LAUNCHER - PROYEK APK ANDROID

Isi:
- Aplikasi Android WebView dengan launcher HTML di dalam APK.
- Tombol Buka Winlator mencoba membuka aplikasi dengan package ID com.winlator.
- Menu konfigurasi hanya menyimpan pilihan profil di aplikasi; tidak mengubah container Winlator secara otomatis.

CARA BUILD TANPA PC (GITHUB):
1. Buat repository GitHub baru.
2. Upload seluruh isi ZIP ini ke repository (bukan file ZIP-nya saja).
3. Buka tab Actions.
4. Pilih workflow "Build Android APK" lalu tekan Run workflow.
5. Setelah selesai, buka hasil run dan unduh Artifacts bernama Naruto-Storm-Revolution-Launcher-APK.
6. Ekstrak artifact ZIP, lalu instal app-debug.apk di Android.

Catatan:
- Ini proyek siap-build, bukan APK yang sudah dikompilasi.
- Build membutuhkan koneksi internet di GitHub Actions.
- Launcher tidak menyertakan game PC, BIOS, atau file Winlator.
- Jika package ID Winlator di perangkat berbeda, tombol buka mungkin perlu disesuaikan.
