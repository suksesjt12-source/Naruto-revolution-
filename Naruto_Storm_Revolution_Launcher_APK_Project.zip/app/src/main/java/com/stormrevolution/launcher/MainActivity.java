package com.stormrevolution.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0D0D12);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void openWinlator() {
                runOnUiThread(() -> {
                    Intent intent = getPackageManager().getLaunchIntentForPackage("com.winlator");
                    if (intent != null) {
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this,
                            "Winlator belum terdeteksi. Silakan pasang atau buka secara manual.",
                            Toast.LENGTH_LONG).show();
                    }
                });
            }
        }, "AndroidLauncher");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
